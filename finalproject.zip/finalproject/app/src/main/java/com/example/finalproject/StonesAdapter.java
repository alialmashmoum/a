package com.example.finalproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StonesAdapter extends RecyclerView.Adapter {

    ArrayList<stones> sArray ;
    Context context;

    public StonesAdapter(ArrayList<stones> sArray, Context context) {
        this.sArray = sArray;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.stones_list_itme,parent,false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((ViewHolder)holder).amg.setImageResource(sArray.get(position).getAmg());
        ((ViewHolder)holder).name.setText(sArray.get(position).getName());
        ((ViewHolder)holder).age.setText(sArray.get(position).getAge()+"");

    }

    @Override
    public int getItemCount() {
        return sArray.size();
    }


   public static class ViewHolder extends RecyclerView.ViewHolder{

       public ImageView amg ;
        public TextView name ;
        public TextView age ;
        public View view;


       public ViewHolder(@NonNull View itemView) {
           super(itemView);
           view = itemView ; //مهم السطر هذا
           amg = itemView.findViewById(R.id.imageView2);
           name = itemView.findViewById(R.id.textView5);
           age = itemView.findViewById(R.id.textView6);
       }
   }



}
