package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Bundle z = getIntent().getExtras();

        Bundle v = getIntent().getExtras();


        Button u = findViewById(R.id.button3);
        Button y = findViewById(R.id.button4);
        Button t = findViewById(R.id.button5);



        u.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent r = new Intent(MainActivity2.this , MainActivity3.class);

                startActivity(r);

            }
        });

        y.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             Intent w = new Intent(MainActivity2.this , MainActivity4.class);

              startActivity(w);


            }
        });

        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             Intent q = new Intent(MainActivity2.this , MainActivity5.class);

             startActivity(q);


            }
        });



    }

    public static class MainActivity11 extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main11);
        }
    }
}