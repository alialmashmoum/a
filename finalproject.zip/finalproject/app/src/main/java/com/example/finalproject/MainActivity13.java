package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity13 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main13);
        Bundle g = getIntent().getExtras();

        ArrayList<stones> people = new ArrayList<>();

        stones a = new stones("ail",R.drawable.people5,15);
        stones s = new stones("ail",R.drawable.people5,15);
        stones d = new stones("Abdallah",R.drawable.people5,15);
        stones f = new stones("Ahmed",R.drawable.people5,15);

        people.add(a);//0
        people.add(s);//1
        people.add(d);//2
        people.add(f);//3

        RecyclerView w = findViewById(R.id.recyclerview);


        w.setHasFixedSize(true);
        RecyclerView.LayoutManager rv = new LinearLayoutManager(this);
        w.setLayoutManager(rv);


        StonesAdapter sa = new StonesAdapter(people,this);
        w.setAdapter(sa);

    }
}