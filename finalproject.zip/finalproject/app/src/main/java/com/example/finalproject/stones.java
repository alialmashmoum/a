package com.example.finalproject;

public class stones {

private String name ;
private int amg ;
private int age ;

    public stones(String name, int amg, int age) {
        this.name = name;
        this.amg = amg;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAmg() {
        return amg;
    }

    public void setAmg(int amg) {
        this.amg = amg;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
